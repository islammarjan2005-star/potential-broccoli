# excel template filler
# fills an excel template with placeholders using calculated values and source data.
# similar approach to word_output.r but for excel.
#
# placeholder format: {{placeholder_name}}
# example: {{emp16_cur}}, {{emp16_dq}}, {{unemp_rt_dy}}
#
# for source data: columns should have dataset identifier codes as headers
# (e.g., mgrz, lf24, mgsc) and data will be matched and populated below.

suppressPackageStartupMessages({

  library(openxlsx)
  library(dplyr)
  library(tibble)
  library(DBI)
  library(RPostgres)
})

# placeholder definitions
# maps placeholder names to the variable names from calculations.r

PLACEHOLDER_MAP <- list(
  # employment 16+
  EMP16_CUR = "emp16_cur",
  EMP16_DQ = "emp16_dq",
  EMP16_DY = "emp16_dy",
  EMP16_DC = "emp16_dc",
  EMP16_DE = "emp16_de",


  # employment rate
  EMP_RT_CUR = "emp_rt_cur",
  EMP_RT_DQ = "emp_rt_dq",
  EMP_RT_DY = "emp_rt_dy",
  EMP_RT_DC = "emp_rt_dc",
  EMP_RT_DE = "emp_rt_de",

  # unemployment 16+
  UNEMP16_CUR = "unemp16_cur",
  UNEMP16_DQ = "unemp16_dq",
  UNEMP16_DY = "unemp16_dy",
  UNEMP16_DC = "unemp16_dc",
  UNEMP16_DE = "unemp16_de",

  # unemployment rate
  UNEMP_RT_CUR = "unemp_rt_cur",
  UNEMP_RT_DQ = "unemp_rt_dq",
  UNEMP_RT_DY = "unemp_rt_dy",
  UNEMP_RT_DC = "unemp_rt_dc",
  UNEMP_RT_DE = "unemp_rt_de",

  # inactivity 16-64
  INACT_CUR = "inact_cur",
  INACT_DQ = "inact_dq",
  INACT_DY = "inact_dy",
  INACT_DC = "inact_dc",
  INACT_DE = "inact_de",

  # inactivity 50-64
  INACT5064_CUR = "inact5064_cur",
  INACT5064_DQ = "inact5064_dq",
  INACT5064_DY = "inact5064_dy",
  INACT5064_DC = "inact5064_dc",
  INACT5064_DE = "inact5064_de",

  # inactivity rate 16-64
  INACT_RT_CUR = "inact_rt_cur",
  INACT_RT_DQ = "inact_rt_dq",
  INACT_RT_DY = "inact_rt_dy",
  INACT_RT_DC = "inact_rt_dc",
  INACT_RT_DE = "inact_rt_de",

  # inactivity rate 50-64
  INACT5064_RT_CUR = "inact5064_rt_cur",
  INACT5064_RT_DQ = "inact5064_rt_dq",
  INACT5064_RT_DY = "inact5064_rt_dy",
  INACT5064_RT_DC = "inact5064_rt_dc",
  INACT5064_RT_DE = "inact5064_rt_de",

  # vacancies
  VAC_CUR = "vac_cur",
  VAC_DQ = "vac_dq",
  VAC_DY = "vac_dy",
  VAC_DC = "vac_dc",
  VAC_DE = "vac_de",

  # payroll
  PAYROLL_CUR = "payroll_cur",
  PAYROLL_DQ = "payroll_dq",
  PAYROLL_DY = "payroll_dy",
  PAYROLL_DC = "payroll_dc",
  PAYROLL_DE = "payroll_de",

  # wages nominal
  WAGES_CUR = "latest_wages",
  WAGES_DQ = "wages_change_q",
  WAGES_DY = "wages_change_y",
  WAGES_DC = "wages_change_covid",
  WAGES_DE = "wages_change_election",

  # wages cpi adjusted
  WAGES_CPI_CUR = "latest_wages_cpi",
  WAGES_CPI_DQ = "wages_cpi_change_q",
  WAGES_CPI_DY = "wages_cpi_change_y",
  WAGES_CPI_DC = "wages_cpi_change_covid",
  WAGES_CPI_DE = "wages_cpi_change_election",

  # period labels
  LFS_PERIOD = "lfs_period_label",
  PAYROLL_PERIOD = "payroll_period_label",
  RENDER_DATE = "render_date"
)

# database helper

fetch_db <- function(query) {
  conn <- DBI::dbConnect(RPostgres::Postgres())
  tryCatch({
    result <- DBI::dbGetQuery(conn, query)
    tibble::as_tibble(result)
  }, error = function(e) {
    warning("DB error: ", e$message)
    tibble::tibble()
  }, finally = DBI::dbDisconnect(conn))
}

# column name to dataset code mappings
# maps human-readable column names (in template) to dataset identifier codes
# complete list - covers all codes from the database
#
# structure: "column name in excel" = "dataset_code"
# multiple column name variations map to the same code for flexibility

# lfs data (labour_market__age_group)
# codes: mgrz, lf24, mgsc, mgsx, lf2m, lf2s, lf2a, lf2w
LFS_COLUMN_MAP <- c(
  # mgrz - employment 16+ level (thousands)
  "Employment 16+ (000s)" = "MGRZ",
  "Employment 16+" = "MGRZ",
  "Employment (000s) 16+" = "MGRZ",
  "Employment level" = "MGRZ",
  "level" = "MGRZ",  # Generic from Sheet 2

  # lf24 - employment rate 16-64 (%)
  "Employment Rate 16-64 (%)" = "LF24",
  "Employment rate (16-64)" = "LF24",
  "Employment rate" = "LF24",
  "Employment rate (%)" = "LF24",
  "rate (%)" = "LF24",  # Generic from Sheet 2

  # mgsc - unemployment 16+ level (thousands)
  "Unemployment 16+ (000s)" = "MGSC",
  "Unemployment 16+" = "MGSC",
  "Unemployment (000s) 16+" = "MGSC",
  "Unemployment, 16+ (000s)" = "MGSC",
  "Unemployment level" = "MGSC",

  # mgsx - unemployment rate 16+ (%)
  "Unemployment Rate 16+ (%)" = "MGSX",
  "Unemployment rate, 16+" = "MGSX",
  "Unemployment rate" = "MGSX",
  "Unemployment rate (%)" = "MGSX",

  # lf2m - inactivity 16-64 level (thousands)
  "Inactivity 16-64 (000s)" = "LF2M",
  "Inactivity 16-64" = "LF2M",
  "Inactivity (000s) 16-64" = "LF2M",
  "Economic inactivity (000s) (16-64)" = "LF2M",
  "Inactivity level" = "LF2M",
  "Total economically inactive aged 16-64 (thousands)4" = "LF2M",

  # lf2s - inactivity rate 16-64 (%)
  "Inactivity Rate 16-64 (%)" = "LF2S",
  "Inactivity rate 16-64" = "LF2S",
  "Economic inactivity rate (16-64)" = "LF2S",
  "Inactivity rate (%)" = "LF2S",

  # lf2a - inactivity 50-64 level (thousands)
  "Inactivity 50-64 (000s)" = "LF2A",
  "Inactivity 50-64" = "LF2A",
  "50-64s inactivity (000s)" = "LF2A",

  # lf2w - inactivity rate 50-64 (%)
  "Inactivity Rate 50-64 (%)" = "LF2W",
  "Inactivity rate 50-64" = "LF2W",
  "50-64s inactivity rate" = "LF2W"
)

# vacancies (labour_market__vacancies_business)
# codes: ap2y, ap3k
VACANCIES_COLUMN_MAP <- c(
  # ap2y - vacancies level (thousands)
  "Vacancies (000s)" = "AP2Y",
  "Vacancies" = "AP2Y",
  "Total vacancies" = "AP2Y",

  # ap3k - quarterly change (thousands)
  "Quarterly Change (000s)" = "AP3K",
  "Quarterly change" = "AP3K"
)

# wages total (labour_market__weekly_earnings_total)
# codes: kab9, kac3, kac6, kac9
WAGES_TOTAL_COLUMN_MAP <- c(
  # kab9 - awe total weekly (£)
  "AWE Total (£/week)" = "KAB9",
  "AWE Total" = "KAB9",
  "Weekly Earnings     (£)" = "KAB9",
  "Weekly Earnings (£)" = "KAB9",
  "Total pay" = "KAB9",

  # kac3 - awe total yoy growth (%)
  "AWE Total YoY (%)" = "KAC3",
  "AWE Total YoY" = "KAC3",
  "% changes year on year" = "KAC3",
  "Total pay growth" = "KAC3",

  # kac6 - awe total private yoy (%)
  "AWE Total Private YoY (%)" = "KAC6",
  "AWE Total Private YoY" = "KAC6",

  # kac9 - awe total public yoy (%)
  "AWE Total Public YoY (%)" = "KAC9",
  "AWE Total Public YoY" = "KAC9"
)

# wages regular (labour_market__weekly_earnings_regular)
# codes: kai7, kai9, kaj4, kaj7
WAGES_REGULAR_COLUMN_MAP <- c(
  # kai7 - awe regular weekly (£)
  "AWE Regular (£/week)" = "KAI7",
  "AWE Regular" = "KAI7",
  "Regular pay" = "KAI7",

  # kai9 - awe regular yoy growth (%)
  "AWE Regular YoY (%)" = "KAI9",
  "AWE Regular YoY" = "KAI9",
  "Regular pay growth" = "KAI9",

  # kaj4 - awe regular private yoy (%)
  "AWE Regular Private YoY (%)" = "KAJ4",
  "AWE Regular Private YoY" = "KAJ4",

  # kaj7 - awe regular public yoy (%)
  "AWE Regular Public YoY (%)" = "KAJ7",
  "AWE Regular Public YoY" = "KAJ7"
)

# inactivity by reason (labour_market__inactivity)
# codes: lf63, lf65, lf67, lf69, lfl8, lf6b, lf6d
INACTIVITY_REASON_COLUMN_MAP <- c(
  # lf63 - student
  "Student" = "LF63",

  # lf65 - looking after family/home
  "Looking after family / home" = "LF65",
  "Looking after family/home" = "LF65",
  "Family/Home" = "LF65",

  # lf67 - temporary sick
  "Temp sick" = "LF67",
  "Temporary sick" = "LF67",
  "Temp Sick" = "LF67",

  # lf69 - long-term sick
  "Long-term sick" = "LF69",
  "Long-term Sick" = "LF69",

  # lfl8 - discouraged workers
  "Discouraged workers1" = "LFL8",
  "Discouraged workers" = "LFL8",
  "Discouraged" = "LFL8",

  # lf6b - retired
  "Retired" = "LF6B",

  # lf6d - other
  "Other2" = "LF6D",
  "Other" = "LF6D"
)

# redundancy (labour_market__redundancies)
# codes: beir
REDUNDANCY_COLUMN_MAP <- c(
  # beir - redundancy rate per 1000
  "Redundancy Rate (per 1000)" = "BEIR",
  "Redundancy rate" = "BEIR",
  "Rate per thousand2" = "BEIR",
  "Rate per thousand" = "BEIR"
)

# days lost (labour_market__disputes)
# codes: bbfw
DAYS_LOST_COLUMN_MAP <- c(
  # bbfw - working days lost (thousands)
  "Days Lost (000s)" = "BBFW",
  "Days lost" = "BBFW",
  "Working days lost" = "BBFW"
)

# industry (labour_market__employees_industry)
# codes: a-s (sic sections)
INDUSTRY_COLUMN_MAP <- c(
  # a - agriculture, forestry and fishing
  "Agriculture" = "A",
  "A-Agriculture" = "A",

  # b - mining and quarrying
  "Mining" = "B",
  "B-Mining" = "B",

  # c - manufacturing
  "Manufacturing" = "C",
  "C-Manufacturing" = "C",

  # d - electricity, gas, steam
  "Electricity" = "D",
  "D-Electricity" = "D",

  # e - water supply, sewerage
  "Water" = "E",
  "E-Water" = "E",

  # f - construction
  "Construction" = "F",
  "F-Construction" = "F",

  # g - wholesale and retail trade
  "Retail" = "G",
  "Wholesale and retail" = "G",
  "G-Retail" = "G",

  # h - transportation and storage
  "Transport" = "H",
  "Transportation" = "H",
  "H-Transport" = "H",

  # i - accommodation and food service
  "Hospitality" = "I",
  "Accommodation and food" = "I",
  "I-Hospitality" = "I",

  # j - information and communication
  "IT" = "J",
  "Information and communication" = "J",
  "IT & Comms" = "J",
  "J-IT & Comms" = "J",

  # k - financial and insurance
  "Finance" = "K",
  "Financial services" = "K",
  "K-Finance" = "K",

  # l - real estate
  "Real Estate" = "L",
  "Real estate" = "L",
  "L-Real Estate" = "L",

  # m - professional, scientific, technical
  "Professional" = "M",
  "Professional services" = "M",
  "M-Professional" = "M",

  # n - administrative and support
  "Admin" = "N",
  "Administrative" = "N",
  "N-Admin" = "N",

  # o - public administration and defence
  "Public Admin" = "O",
  "Public administration" = "O",
  "O-Public Admin" = "O",

  # p - education
  "Education" = "P",
  "P-Education" = "P",

  # q - human health and social work
  "Health" = "Q",
  "Health and social" = "Q",
  "Q-Health" = "Q",

  # r - arts, entertainment, recreation
  "Arts" = "R",
  "Arts and recreation" = "R",
  "R-Arts" = "R",

  # s - other service activities
  "Other Services" = "S",
  "Other services" = "S",
  "S-Other Services" = "S"
)

# source data fetchers
# these return data with dataset_indentifier_code as columns

fetch_lfs_source <- function() {
  query <- 'SELECT time_period, dataset_indentifier_code, value
            FROM "ons"."labour_market__age_group"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, dataset_indentifier_code) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = dataset_indentifier_code, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_vacancies_source <- function() {
  query <- 'SELECT time_period, dataset_indentifier_code, value
            FROM "ons"."labour_market__vacancies_business"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, dataset_indentifier_code) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = dataset_indentifier_code, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_payroll_source <- function() {
  query <- 'SELECT time_period, unit_type, value
            FROM "ons"."labour_market__payrolled_employees"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, unit_type) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = unit_type, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_wages_total_source <- function() {
  query <- 'SELECT time_period, dataset_indentifier_code, value
            FROM "ons"."labour_market__weekly_earnings_total"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, dataset_indentifier_code) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = dataset_indentifier_code, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_wages_cpi_source <- function() {
  query <- 'SELECT time_period, earnings_type, earnings_metric, value
            FROM "ons"."labour_market__weekly_earnings_cpi"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(
      value = as.numeric(value),
      col_name = paste0(earnings_type, "_", earnings_metric)
    ) %>%
    group_by(time_period, col_name) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = col_name, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_wages_regular_source <- function() {
  query <- 'SELECT time_period, dataset_indentifier_code, value
            FROM "ons"."labour_market__weekly_earnings_regular"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, dataset_indentifier_code) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = dataset_indentifier_code, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_inactivity_source <- function() {
  query <- 'SELECT time_period, dataset_indentifier_code, value
            FROM "ons"."labour_market__inactivity"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, dataset_indentifier_code) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = dataset_indentifier_code, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_redundancy_source <- function() {
  query <- 'SELECT time_period, dataset_indentifier_code, value
            FROM "ons"."labour_market__redundancies"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, dataset_indentifier_code) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = dataset_indentifier_code, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

fetch_industry_source <- function() {
  query <- 'SELECT time_period, sic_section, value
            FROM "ons"."labour_market__employees_industry"'
  raw <- fetch_db(query)
  if (nrow(raw) == 0) return(tibble())

  raw %>%
    mutate(value = as.numeric(value)) %>%
    group_by(time_period, sic_section) %>%
    summarise(value = first(value), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = sic_section, values_from = value) %>%
    rename(Date = time_period) %>%
    arrange(Date)
}

# placeholder replacement functions

# ' find all cells containing placeholders in a worksheet
# ' @param wb workbook object
# ' @param sheet sheet name
# ' @return data frame with row, col, placeholder_name for each found placeholder
find_placeholders <- function(wb, sheet) {
  # read the sheet as text to find placeholders
  data <- tryCatch({
    read.xlsx(wb, sheet = sheet, colNames = FALSE, skipEmptyRows = FALSE, skipEmptyCols = FALSE)
  }, error = function(e) {
    return(data.frame())
  })

  if (nrow(data) == 0 || ncol(data) == 0) return(data.frame())

  placeholders <- data.frame(
    row = integer(),
    col = integer(),
    placeholder = character(),
    stringsAsFactors = FALSE
  )

  for (r in seq_len(nrow(data))) {
    for (c in seq_len(ncol(data))) {
      cell_val <- as.character(data[r, c])
      if (!is.na(cell_val) && grepl("\\{\\{[A-Z0-9_]+\\}\\}", cell_val)) {
        # extract placeholder name(s)
        matches <- regmatches(cell_val, gregexpr("\\{\\{([A-Z0-9_]+)\\}\\}", cell_val))[[1]]
        for (m in matches) {
          name <- gsub("\\{\\{|\\}\\}", "", m)
          placeholders <- rbind(placeholders, data.frame(
            row = r,
            col = c,
            placeholder = name,
            stringsAsFactors = FALSE
          ))
        }
      }
    }
  }

  placeholders
}

# ' replace a placeholder in a cell with a value
# ' @param wb workbook object
# ' @param sheet sheet name
# ' @param row row number
# ' @param col column number
# ' @param placeholder placeholder name (without braces)
# ' @param value value to insert
replace_placeholder <- function(wb, sheet, row, col, placeholder, value) {
  # write the value to the cell
  writeData(wb, sheet, value, startRow = row, startCol = col, colNames = FALSE)
  invisible(wb)
}

# ' fill source data into a sheet based on column headers
# ' uses column_map to translate human-readable names to dataset codes
# '
# ' @param wb workbook object
# ' @param sheet sheet name
# ' @param source_data data frame with date column and dataset code columns
# ' @param column_map named vector mapping column names to dataset codes
# ' @param header_row row number containing column headers (human-readable names)
# ' @param data_start_row row number where data should start
# ' @param date_col column number for dates (default 1)
fill_source_data <- function(wb, sheet, source_data, column_map,
                              header_row, data_start_row, date_col = 1) {
  if (is.null(source_data) || nrow(source_data) == 0) {
    message("  No source data to fill for sheet: ", sheet)
    return(wb)
  }

  # read the header row to find column mappings
  headers <- tryCatch({
    read.xlsx(wb, sheet = sheet, rows = header_row, colNames = FALSE)
  }, error = function(e) {
    return(data.frame())
  })

  if (ncol(headers) == 0) {
    message("  Could not read headers for sheet: ", sheet)
    return(wb)
  }

  headers <- as.character(unlist(headers[1, ]))

  # get available dataset codes from source data
  source_codes <- names(source_data)
  filled_cols <- 0

  for (i in seq_along(headers)) {
    header_val <- trimws(headers[i])
    if (is.na(header_val) || header_val == "") next

    # check if header is "date" or similar
    if (tolower(header_val) %in% c("date", "period", "time_period", "time period")) {
      if ("Date" %in% source_codes) {
        date_data <- source_data[["Date"]]
        for (r in seq_along(date_data)) {
          writeData(wb, sheet, date_data[r], startRow = data_start_row + r - 1, startCol = i, colNames = FALSE)
        }
        message("    Filled column ", i, " (", header_val, ") with dates: ", length(date_data), " rows")
        filled_cols <- filled_cols + 1
      }
      next
    }

    # column headers are always human-readable names
    # we use the column_map to find the corresponding dataset code
    dataset_code <- NA

    # use column_map to translate column name -> dataset code
    if (!is.null(column_map) && length(column_map) > 0) {

      # 1. exact match
      if (header_val %in% names(column_map)) {
        dataset_code <- column_map[header_val]
      }

      # 2. case-insensitive match
      if (is.na(dataset_code)) {
        matching_names <- names(column_map)[tolower(names(column_map)) == tolower(header_val)]
        if (length(matching_names) > 0) {
          dataset_code <- column_map[matching_names[1]]
        }
      }

      # 3. partial match (column name contains a mapped name or vice versa)
      if (is.na(dataset_code)) {
        for (map_name in names(column_map)) {
          # check if header contains the map name
          if (grepl(map_name, header_val, fixed = TRUE, ignore.case = TRUE)) {
            dataset_code <- column_map[map_name]
            break
          }
          # check if map name contains the header (for short headers)
          if (nchar(header_val) >= 3 && grepl(header_val, map_name, fixed = TRUE, ignore.case = TRUE)) {
            dataset_code <- column_map[map_name]
            break
          }
        }
      }
    }

    # skip if no match found in column_map
    if (is.na(dataset_code)) {
      next
    }

    # check if this dataset code exists in source data
    if (dataset_code %in% source_codes) {
      col_data <- source_data[[dataset_code]]

      # write the column data starting at data_start_row
      for (r in seq_along(col_data)) {
        writeData(wb, sheet, col_data[r], startRow = data_start_row + r - 1, startCol = i, colNames = FALSE)
      }

      message("    Filled column ", i, " (", header_val, " -> ", dataset_code, ") with ", length(col_data), " rows")
      filled_cols <- filled_cols + 1
    } else {
      message("    Warning: Dataset code '", dataset_code, "' for '", header_val, "' not found in source data")
    }
  }

  message("  Filled ", filled_cols, " columns total")
  invisible(wb)
}

# main template filler function

# ' fill an excel template with calculated values and source data
# '
# ' @param template_path path to excel template file
# ' @param output_path path for output file
# ' @param calculations_path path to calculations.r
# ' @param config_path path to config.r
# ' @param sheet_config list defining how to fill each sheet (see below)
# ' @param verbose print progress messages
# '
# ' @details
# ' sheet_config should be a list where each element is named by sheet name and contains:
# '   - source_fetcher: function name to fetch source data (e.g., "fetch_lfs_source")
# '   - header_row: row number with column headers (dataset codes)
# '   - data_start_row: row number where data should start
# '
# ' @examples
# ' sheet_config <- list(
# '   "lfs data" = list(
# '     source_fetcher = "fetch_lfs_source",
# '     header_row = 10,
# '     data_start_row = 11
# '   )
# ' )
fill_excel_template <- function(template_path,
                                 output_path,
                                 calculations_path = "utils/calculations.R",
                                 config_path = "utils/config.R",
                                 sheet_config = NULL,
                                 verbose = TRUE) {

  if (!file.exists(template_path)) {
    stop("Template file not found: ", template_path)
  }

  # load the template
  if (verbose) message("Loading template: ", template_path)
  wb <- loadWorkbook(template_path)

  # source config and calculations
  if (verbose) message("Sourcing calculations...")
  calc_env <- new.env()

  if (file.exists(config_path)) {
    source(config_path, local = calc_env)
  }

  if (file.exists(calculations_path)) {
    source(calculations_path, local = calc_env)
  } else {
    stop("calculations.R not found at: ", calculations_path)
  }

  # add render date
  calc_env$render_date <- format(Sys.Date(), "%d %B %Y")

  # get all sheet names
  sheets <- names(wb)
  if (verbose) message("Found ", length(sheets), " sheets")

  # process each sheet for placeholders
  for (sheet in sheets) {
    if (verbose) message("Processing sheet: ", sheet)

    # find and replace placeholders
    placeholders <- find_placeholders(wb, sheet)

    if (nrow(placeholders) > 0) {
      if (verbose) message("  Found ", nrow(placeholders), " placeholders")

      for (i in seq_len(nrow(placeholders))) {
        ph <- placeholders[i, ]
        ph_name <- ph$placeholder

        # look up the variable name
        var_name <- PLACEHOLDER_MAP[[ph_name]]

        if (is.null(var_name)) {
          if (verbose) message("    Warning: Unknown placeholder {{", ph_name, "}}")
          next
        }

        # get the value from calc_env
        if (exists(var_name, envir = calc_env)) {
          value <- get(var_name, envir = calc_env)
          replace_placeholder(wb, sheet, ph$row, ph$col, ph_name, value)
          if (verbose) message("    Replaced {{", ph_name, "}} at R", ph$row, "C", ph$col, " with ", value)
        } else {
          if (verbose) message("    Warning: Variable '", var_name, "' not found for {{", ph_name, "}}")
        }
      }
    }

    # fill source data if configured
    if (!is.null(sheet_config) && sheet %in% names(sheet_config)) {
      config <- sheet_config[[sheet]]

      if (!is.null(config$source_fetcher)) {
        if (verbose) message("  Fetching source data using: ", config$source_fetcher)

        fetcher_fn <- get(config$source_fetcher)
        source_data <- tryCatch(fetcher_fn(), error = function(e) {
          message("    Error fetching data: ", e$message)
          tibble()
        })

        if (nrow(source_data) > 0) {
          # get the column map (either by name or direct)
          col_map <- NULL
          if (!is.null(config$column_map)) {
            if (is.character(config$column_map)) {
              # it's a name of a map variable
              col_map <- get(config$column_map)
            } else {
              # it's the map itself
              col_map <- config$column_map
            }
          }

          fill_source_data(
            wb = wb,
            sheet = sheet,
            source_data = source_data,
            column_map = col_map,
            header_row = config$header_row,
            data_start_row = config$data_start_row
          )
        }
      }
    }
  }

  # save the filled workbook
  if (verbose) message("Saving to: ", output_path)
  saveWorkbook(wb, output_path, overwrite = TRUE)

  if (verbose) message("Done!")
  invisible(output_path)
}

# example usage

# define sheet configuration for source data
# each entry specifies:
# - source_fetcher: function name to fetch data from db
# - column_map: mapping of column names to dataset codes
# - header_row: row number with column headers
# - data_start_row: row number where data begins

DEFAULT_SHEET_CONFIG <- list(
  # your excel sheets

  # sheet "2" - lfs main indicators (employment, unemployment, inactivity)
  # header row 15 has: date, employment level, employment rate, unemployment level, etc.
  "2" = list(
    source_fetcher = "fetch_lfs_source",
    column_map = "LFS_COLUMN_MAP",
    header_row = 15,
    data_start_row = 16
  ),

  # sheet "11" - inactivity by reason
  # header row 2 has: date, total inactivity, student, family/home, temp sick, long-term sick, etc.
  "11" = list(
    source_fetcher = "fetch_inactivity_source",
    column_map = "INACTIVITY_REASON_COLUMN_MAP",
    header_row = 2,
    data_start_row = 10
  ),

  # sheet "10" - redundancies
  # header row 2 has: date, people level, rate per thousand, men level, etc.
  "10" = list(
    source_fetcher = "fetch_redundancy_source",
    column_map = "REDUNDANCY_COLUMN_MAP",
    header_row = 2,
    data_start_row = 10
  ),

  # sheet "13" - awe total wages (nominal)
  # header row 3 has column types, source data starts around row 18
  "13" = list(
    source_fetcher = "fetch_wages_total_source",
    column_map = "WAGES_TOTAL_COLUMN_MAP",
    header_row = 3,
    data_start_row = 18
  ),

  # sheet "15" - awe regular wages (nominal)
  "15" = list(
    source_fetcher = "fetch_wages_regular_source",
    column_map = "WAGES_REGULAR_COLUMN_MAP",
    header_row = 3,
    data_start_row = 18
  ),

  # sheet "awe real_cpi" - cpi adjusted wages
  # header row 1 has: date, total pay real awe, total pay %, regular pay real awe, etc.
  "AWE Real_CPI" = list(
    source_fetcher = "fetch_wages_cpi_source",
    column_map = NULL,  # Uses combined column names from the query
    header_row = 1,
    data_start_row = 17
  ),

  # sheet "1. payrolled employees (uk)" - hmrc payroll
  # header row 10 has: date, payrolled employees, change on previous month
  "1. Payrolled employees (UK)" = list(
    source_fetcher = "fetch_payroll_source",
    column_map = NULL,  # Uses unit_type from query
    header_row = 10,
    data_start_row = 11
  ),

  # sheet "23. employees industry" - industry breakdown
  "23. Employees Industry" = list(
    source_fetcher = "fetch_industry_source",
    column_map = "INDUSTRY_COLUMN_MAP",
    header_row = 13,
    data_start_row = 14
  )
)

# convenience function for your workbook

# ' fill the labour market stats workbook
# '
# ' @param template_path path to your excel template (with placeholders)
# ' @param output_path path for the filled output
# ' @param verbose show progress messages
fill_lm_stats_workbook <- function(template_path = "LM_Stats_Template.xlsx",
                                    output_path = "LM_Stats_Filled.xlsx",
                                    verbose = TRUE) {

  fill_excel_template(
    template_path = template_path,
    output_path = output_path,
    calculations_path = "utils/calculations.R",
    config_path = "utils/config.R",
    sheet_config = DEFAULT_SHEET_CONFIG,
    verbose = verbose
  )
}

# run with defaults
# fill_lm_stats_workbook(
# template_path = "december 25 lm statss.xlsx",
# output_path = "december 25 lm stats filled.xlsx"
# )
